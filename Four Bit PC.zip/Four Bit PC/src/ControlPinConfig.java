import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class ControlPinConfig  extends Application{
    @Override
    public void start(Stage primaryStage) throws Exception {
        VBox vBox=new VBox();
        List<Data> dataList=new ArrayList<>();
        TextField opt=new TextField();
        TextField cycle=new TextField();
        TextField active=new TextField();
        Label info=new Label("");
        Button load=new Button("LOAD");
        Button add=new Button("Add");
        Button save=new Button("Save");
        vBox.getChildren().addAll(load,new Label("OPT"),opt,new Label("Cycle"),cycle,new Label("Active Pin"),active,add,info,save);
        Scene scene=new Scene(vBox,600,400);
        primaryStage.setScene(scene);
        primaryStage.show();
        add.setOnAction(event -> {
            Data data=new Data(opt.getText(),cycle.getText(),active.getText());
            dataList.add(data);
            active.setText("");
            info.setText(opt.getText()+" "+cycle.getText()+" Added !");
        });
        load.setOnAction(event -> {
            File excel=new File("D:/raw.xlsx");
            FileInputStream fileInputStream= null;
            try {
                fileInputStream = new FileInputStream(excel);
                XSSFWorkbook book = new XSSFWorkbook(fileInputStream);
                XSSFSheet sheet = book.getSheetAt(0);

                Iterator<Row> iterator=sheet.iterator();
                iterator.next();
                while (iterator.hasNext()){
                    Row row = iterator.next();
                    String op=row.getCell(0).getStringCellValue();
                    String op_code=row.getCell(1).getStringCellValue();
                    String des=row.getCell(2).getStringCellValue();
                    String total_state=(int)row.getCell(3).getNumericCellValue()+"";
                    if(total_state=="0") total_state="";
                    String cy=row.getCell(4).getStringCellValue();
                    String micro=row.getCell(5).getStringCellValue();
                    String ac=row.getCell(6).getStringCellValue();
                    Data data=new Data(op,cy,ac,op_code,des,total_state,micro);
                    dataList.add(data);


                }






            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            info.setText("Read Complete");

        });
        save.setOnAction(event -> {

            try {
                FileOutputStream fos_config=new FileOutputStream("Pin_Config.txt");
                BufferedWriter bufferedWriter=new BufferedWriter(new OutputStreamWriter(fos_config));
                for(Data data:dataList){
                    bufferedWriter.write(data.opt+" "+data.cycle+" "+data.acPins+"\n");
                }
                bufferedWriter.flush();
                fos_config.flush();
                fos_config.close();
                FileOutputStream fos_bin=new FileOutputStream("Binary.txt");
                bufferedWriter=new BufferedWriter(new OutputStreamWriter(fos_bin));
                for(Data data:dataList){
                    bufferedWriter.write(data.opt+" "+data.cycle+"\n");
                    for(int i=0;i<40;i++){
                        bufferedWriter.write(data.values[i]+" ");
                    }
                    bufferedWriter.write("\n\n");
                }
                bufferedWriter.flush();
                fos_bin.flush();
                fos_bin.close();
                FileOutputStream fos_hex=new FileOutputStream("Hex.txt");
                bufferedWriter=new BufferedWriter(new OutputStreamWriter(fos_hex));
                for(Data data:dataList){
                    bufferedWriter.write(data.opt+" "+data.cycle+"\n");
                    for(int i=0;i<5;i++){
                        bufferedWriter.write(data.hex_values[i]+" ");
                    }
                    bufferedWriter.write("\n\n");
                }
                bufferedWriter.flush();
                fos_hex.flush();
                fos_hex.close();
                String excelFileName = "Sap.xlsx";
                XSSFWorkbook wb = new XSSFWorkbook();
                XSSFSheet sheet_bin = wb.createSheet("BINARY") ;
                XSSFRow row0 = sheet_bin.createRow(0);
                XSSFCell cell00 = row0.createCell(0);
                XSSFCell cell01 = row0.createCell(1);
                XSSFCell cell02 = row0.createCell(2);
                XSSFCell cell03 = row0.createCell(3);
                XSSFCell cell04 = row0.createCell(4);
                XSSFCell cell05 = row0.createCell(5);
                XSSFCell cell06 = row0.createCell(6);



                cell00.setCellValue("Macro-Instruction");
                cell01.setCellValue("Op-Code");
                cell02.setCellValue("Description");
                cell03.setCellValue("Total T-States");
                cell04.setCellValue("T-State");
                cell05.setCellValue("Micro-Operation");
                cell06.setCellValue("Active");




                int i=7;
                for(String str:AllPins.getAllPins()){
                    XSSFCell cell = row0.createCell(i++);
                    cell.setCellValue(str);
                }
                i=1;
                for(Data data:dataList){
                    XSSFRow row = sheet_bin.createRow(i++);
                    XSSFCell cell0 = row.createCell(0);
                    XSSFCell cell1 = row.createCell(1);
                    XSSFCell cell2 = row.createCell(2);
                    XSSFCell cell3 = row.createCell(3);
                    XSSFCell cell4 = row.createCell(4);
                    XSSFCell cell5 = row.createCell(5);
                    XSSFCell cell6 = row.createCell(6);


                    cell0.setCellValue(data.opt);
                    cell1.setCellValue(data.op_code);
                    cell2.setCellValue(data.des);
                    cell3.setCellValue(data.num_t_state);
                    cell4.setCellValue(data.cycle);
                    cell5.setCellValue(data.micro_op);
                    cell6.setCellValue(data.acPins);
                    for(int j=0;j<40;j++){
                        XSSFCell cell=row.createCell(j+7);
                        cell.setCellValue(data.values[j]);
                    }

                }

                XSSFSheet sheet_hex = wb.createSheet("HEX") ;
                 row0 = sheet_hex.createRow(0);
                 cell00 = row0.createCell(0);
                 cell01 = row0.createCell(1);
                 cell02 = row0.createCell(2);
                 cell03 = row0.createCell(3);
                 cell04 = row0.createCell(4);
                 cell05 = row0.createCell(5);
                 cell06 = row0.createCell(6);



                cell00.setCellValue("Macro-Instruction");
                cell01.setCellValue("Op-Code");
                cell02.setCellValue("Description");
                cell03.setCellValue("Total T-States");
                cell04.setCellValue("T-State");
                cell05.setCellValue("Micro-Operation");
                cell06.setCellValue("Active");
                for(i=0;i<5;i++){
                    XSSFCell cell = row0.createCell(i+7);
                    cell.setCellValue(""+i);
                }
                i=1;
                for(Data data:dataList){
                    XSSFRow row = sheet_hex.createRow(i++);
                    XSSFCell cell0 = row.createCell(0);
                    XSSFCell cell1 = row.createCell(1);
                    XSSFCell cell2 = row.createCell(2);
                    XSSFCell cell3 = row.createCell(3);
                    XSSFCell cell4 = row.createCell(4);
                    XSSFCell cell5 = row.createCell(5);
                    XSSFCell cell6 = row.createCell(6);


                    cell0.setCellValue(data.opt);
                    cell1.setCellValue(data.op_code);
                    cell2.setCellValue(data.des);
                    cell3.setCellValue(data.num_t_state);
                    cell4.setCellValue(data.cycle);
                    cell5.setCellValue(data.micro_op);
                    cell6.setCellValue(data.acPins);
                    for(int j=0;j<5;j++){
                        XSSFCell cell=row.createCell(j+7);
                        cell.setCellValue(data.hex_values[j]);
                    }
                }

                FileOutputStream fileOut = new FileOutputStream(excelFileName);
                wb.write(fileOut);
                fileOut.flush();
                fileOut.close();

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            info.setText("File Saved");
        });




    }

    public static void main(String[] args) {
        Application.launch();
    }
}
