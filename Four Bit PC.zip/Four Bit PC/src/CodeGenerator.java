import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

public class CodeGenerator extends Application{
    HashMap<String,String> valuesAddMap=new HashMap<>();
    int valueAddress=32;
    String[] hex_codes=new String[1024];
    HashMap<String,String> opcodes=new HashMap<>();
    List<String> oplist2=new ArrayList<>();
    List<String> withAddress=new ArrayList<>();

    @Override

    public void start(Stage primaryStage) throws Exception {
        opcodes.put("LDA","00");
        opcodes.put("HLT","0F");
        opcodes.put("IN","02");
        opcodes.put("STA","01");
        opcodes.put("OUT","03");
        opcodes.put("NOP","07");
        opcodes.put("JMP","08");
        opcodes.put("ADC","0A");
        opcodes.put("SBB","0C");
        opcodes.put("CMP","10");
        opcodes.put("TEST","11");
        opcodes.put("AND","12");
        opcodes.put("XOR","13");
        opcodes.put("PUSH","14");
        opcodes.put("POP","15");
        opcodes.put("CALL","16");
        opcodes.put("RET","17");
        opcodes.put("SHL","18");
        opcodes.put("SHR","19");
        opcodes.put("JC","1A");
        opcodes.put("JE","1B");
        opcodes.put("END","-1");

        Set<String> oplist1=opcodes.keySet();

        oplist2.add("MOV");
        oplist2.add("ADD");
        oplist2.add("SUB");

        withAddress.add("LDA");
        withAddress.add("STA");
        withAddress.add("JMP");
        withAddress.add("CALL");
        withAddress.add("JC");
        withAddress.add("JE");

        HBox parent=new HBox();
        VBox vBox=new VBox();
        TextArea code=new TextArea();
        HBox hBox=new HBox();
        TextField address=new TextField();
        address.setText(Integer.toHexString(valueAddress));
        TextField value=new TextField();
        Button add=new Button("Add Value");
        hBox.getChildren().addAll(new Label("Address:"),address,new Label("Value:"),value,add);
        Button save=new Button("Save");
        TextArea values=new TextArea();
        TextArea hex_code_area=new TextArea();
        vBox.getChildren().addAll(new Label("Code"),code,new Label("Value"),hBox,values,save);

        add.setOnAction(event -> {
            valuesAddMap.put(address.getText(),Integer.toHexString(Integer.parseInt(value.getText())));
            values.setText(values.getText()+address.getText()+":"+Integer.toHexString(Integer.parseInt(value.getText()))+"\n");
            valueAddress=Integer.parseInt(address.getText(),16);
            hex_codes[valueAddress]=Integer.toHexString(Integer.parseInt(value.getText()));
            valueAddress=Integer.parseInt(address.getText(),16)+1;
            address.setText(Integer.toHexString(valueAddress));
        });
        save.setOnAction(event -> {
            String codes=code.getText();
            String[] code_lines=codes.split("\n");
            int current_address=0;
            for(String s:code_lines){
                String st=s.split(" ")[0];
                if(oplist1.contains(st)){
                    if(withAddress.contains(st)){
                        hex_codes[current_address++]=opcodes.get(st);
                        hex_codes[current_address++]=s.split(" ")[1];
                    }
                    else{
                        hex_codes[current_address++]=opcodes.get(st);
                    }
                }
              //  System.out.println(st);
                    if(st.equals("MOV")){
                        System.out.println("inside move");
                        if(s.startsWith("MOV B")) hex_codes[current_address++]="04";
                        else if(s.startsWith("MOV ACC, B")) hex_codes[current_address++]="05";
                        else{
                            hex_codes[current_address++]="06";
                            hex_codes[current_address++]=s.substring(s.indexOf(",")+1).trim();
                        }
                    }
                    else if(st.equals("ADD")){
                        if(s.startsWith("ADD B")) hex_codes[current_address++]="09";
                        else{
                            hex_codes[current_address++]="0D";
                            hex_codes[current_address++]=s.split(" ")[1].trim();
                        }
                    }
                    else if(st.equals("SUB")){
                        if(s.startsWith("SUB B")) hex_codes[current_address++]="0C";
                        else{
                            hex_codes[current_address++]="0E";
                            hex_codes[current_address++]=s.substring(s.indexOf('[')+1,s.indexOf(']')).trim();
                        }
                    }
                }
           // }
            for(int i=current_address;i<32;i++) hex_codes[i]="FF";

            try {
                File file=new File("code.bin");
                FileOutputStream fos=new FileOutputStream(file);
                hex_code_area.setText("");
                for(int i=0;i<valueAddress;i++){
                    int val=Integer.parseInt(hex_codes[i],16);
                    if(val>127) val=-256+val;
                   Byte b=(byte) val;
                   fos.write(b);
                   System.out.println(i+" "+hex_codes[i]);
                   hex_code_area.setText(hex_code_area.getText()+hex_codes[i]+"\n");
                }
                //bufferedWriter.close();
                fos.flush();
                fos.close();
                System.out.println("File Saved !!!");



            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        });

        parent.getChildren().addAll(vBox,hex_code_area);
        Scene scene=new Scene(parent,1000,600);
        primaryStage.setScene(scene);
        primaryStage.show();

    }
}
