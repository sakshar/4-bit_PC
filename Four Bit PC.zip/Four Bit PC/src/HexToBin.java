import java.io.*;

public class HexToBin {


    public static void convert_file(String filename){
        File file=new File(filename);
        try {
            BufferedReader bufferedReader=new BufferedReader(new FileReader(file));
            FileOutputStream fos=new FileOutputStream("bin/"+filename);
            String line;
            while((line=bufferedReader.readLine())!=null){
                int val=Integer.parseInt(line,16);
                if(val>127) val=val-256;
                Byte b=(byte)val;
                fos.write(b);

            }
            bufferedReader.close();
            fos.flush();
            fos.close();
            System.out.println("Complete : "+filename);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
    public static void main(String[] args) {
        convert_file("adrom.bin");
        convert_file("crom1.bin");
        convert_file("crom2.bin");
        convert_file("crom3.bin");
        convert_file("crom4.bin");
        convert_file("crom0.bin");
        convert_file("boot.BIN");


    }
}
