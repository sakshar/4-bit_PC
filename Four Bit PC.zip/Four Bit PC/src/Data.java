import java.util.ArrayList;
import java.util.List;

public class Data {
    String opt;
    String cycle;
    String acPins;
    List<String> activePins;
    int[] values;
    String[] hex_values;
    String op_code;
    String des;
    String num_t_state;
    String micro_op;



    public Data(String opt, String cycle, List<String> activePins) {
        this.opt = opt;
        this.cycle = cycle;
        this.activePins = activePins;
        values=new int[40];
        hex_values=new String[5];
        String[] allpins=AllPins.getAllPins();
        int i=0;
        for(String pin:allpins){
            boolean isActive=activePins.contains(pin);
            boolean isBar=pin.endsWith("BAR");
            int value=0;
            if(isActive) value=1;
            if(isBar) value=1-value;
            values[i++]=value;
        }
        for(i=0;i<5;i++){
            String str="";
            for(int j=0;i<8;j++){
                str=str+values[i*5+j];
            }
            int hex_value=Integer.parseInt(str,2);
            hex_values[i]=Integer.toHexString(hex_value);
        }
    }

    public Data(String opt, String cycle, String acPins) {
        this.opt = opt;
        this.cycle = cycle;
        this.activePins = new ArrayList<>();
        this.acPins=acPins;
        String[] acpins=acPins.split(",");
        for(String apin:acpins) activePins.add(apin);
        values=new int[40];
        hex_values=new String[5];
        String[] allpins=AllPins.getAllPins();
        int i=0;
        for(String pin:allpins){
            boolean isActive=activePins.contains(pin.trim());
            boolean isBar=pin.endsWith("BAR");
            int value=0;
            if(isActive) value=1;
            if(isBar) value=1-value;
            values[i++]=value;
        }
        for(i=0;i<40;i++) System.out.print(values[i]+" ");
        System.out.println();
        for(i=0;i<5;i++){
            String str="";
            for(int j=0;j<8;j++){

                str=str+values[i*8+j];
            }
            int hex_value=Integer.parseInt(str,2);
            System.out.println(str+"->"+hex_value);
            hex_values[i]=Integer.toHexString(hex_value);
        }
    }

    public Data(String opt, String cycle, String acPins, String op_code, String des, String num_t_state, String micro_op) {
        this.opt = opt;
        this.cycle = cycle;
        this.acPins = acPins;
        this.op_code = op_code;
        this.des = des;
        this.activePins = new ArrayList<>();
        this.num_t_state = num_t_state;
        this.micro_op = micro_op;
        String[] acpins=acPins.split(",");
        for(String apin:acpins) activePins.add(apin.trim());
        values=new int[40];
        hex_values=new String[5];
        String[] allpins=AllPins.getAllPins();
        int i=0;
        for(String pin:allpins){
            boolean isActive=activePins.contains(pin);
            boolean isBar=pin.endsWith("BAR");
            int value=0;
            if(isActive) value=1;
            if(isBar) value=1-value;
            values[i++]=value;
        }
        for(i=0;i<40;i++) System.out.print(values[i]+" ");
        System.out.println();
        for(i=0;i<5;i++){
            String str="";
            for(int j=0;j<8;j++){

                str=str+values[i*8+j];
            }
            int hex_value=Integer.parseInt(str,2);
            System.out.println(str+"->"+hex_value);
            hex_values[i]=Integer.toHexString(hex_value);
        }
    }
}
