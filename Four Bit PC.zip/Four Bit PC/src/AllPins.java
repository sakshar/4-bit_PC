import java.util.ArrayList;
import java.util.List;

public class AllPins {
    public static String[] getAllPins(){
        String []all={"HLT","AS1","AS0","LF_BAR","M","S3","S2","S1","S0","CIN1","CIN2","EF_BAR","EU_BAR","LS","IS","DS",
                "ES_BAR","LT_BAR","ET_BAR","LU_BAR","EB_BAR","LB_BAR","EA_BAR","LA_BAR","EIN_BAR","LIR_BAR","M_BUS",
                "LDR_BAR","EDR_BAR","EDB_BAR","W_BAR","R_BAR","LM_BAR","EM_BAR","CLEAR","CP","EP_BAR","LP","LOAD","RESET"
        };
        return all;

    }
}
